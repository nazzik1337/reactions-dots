const $ = id => document.getElementById(id);
let difficulty = Number(localStorage.getItem("rd-level") || 1);
let round = 1, score = 0, remaining = 0, timerId = null, running = false, best = Number(localStorage.getItem("rd-best") || 0);
const screens = ["home","settings","game","result"];
function show(id){ screens.forEach(s=>$(s).classList.toggle("active",s===id)); }
function dotCount(){ return Math.round(3+(difficulty-1)*12/9); }
function updateSettings(){
  $("level").value=difficulty; $("levelValue").textContent=`${difficulty} / 10`;
  $("countValue").textContent=dotCount();
  $("dotsPreview").innerHTML=Array.from({length:dotCount()},()=>'<i class="preview-dot"></i>').join("");
}
function updateBest(){ $("homeBest").textContent=best; $("bestValue").textContent=best; }
function stop(){ running=false; clearInterval(timerId); timerId=null; }
function startGame(){
  stop(); running=true; round=1; score=0;
  $("scoreValue").textContent=score; $("bestValue").textContent=best;
  show("game"); nextRound();
}
function nextRound(){
  if(!running)return;
  $("roundValue").textContent=round;
  remaining=dotCount(); $("remainingValue").textContent=remaining;
  $("arena").innerHTML='<div class="arena-hint">ПРИГОТУЙСЯ</div>';
  $("gameTip").textContent="Крапочки з'являться після відліку";
  let n=3; $("countdown").textContent=n;
  $("countdown").style.display="grid";
  clearInterval(timerId);
  timerId=setInterval(()=>{
    n--; $("countdown").textContent=n>0?n:"";
    if(n<=0){clearInterval(timerId);timerId=null;showDots();}
  },1000);
}
function showDots(){
  if(!running)return;
  $("countdown").style.display="none";
  const arena=$("arena"); arena.innerHTML="";
  $("gameTip").textContent="Натисни на всі крапочки!";
  const w=arena.clientWidth, h=arena.clientHeight, margin=24;
  const points=[];
  for(let i=0;i<remaining;i++){
    let x,y,tries=0;
    do{
      x=margin+Math.random()*(w-margin*2);
      y=margin+Math.random()*(h-margin*2);
      tries++;
    }while(points.some(p=>Math.hypot(p.x-x,p.y-y)<34)&&tries<80);
    points.push({x,y});
    const dot=document.createElement("button");
    dot.className="dot"; dot.type="button"; dot.setAttribute("aria-label","Крапочка");
    dot.style.left=x+"px"; dot.style.top=y+"px";
    dot.addEventListener("click",()=>{
      if(!running||!dot.isConnected)return;
      dot.remove(); remaining--; score+=10;
      $("remainingValue").textContent=remaining; $("scoreValue").textContent=score;
      if(remaining===0){
        round++; $("gameTip").textContent="Чудово! Наступний раунд…";
        setTimeout(()=>{if(running)nextRound();},450);
      }
    });
    arena.appendChild(dot);
  }
}
function finish(){
  stop(); $("finalScore").textContent=score;
  const newRecord=score>best;
  if(newRecord){best=score;localStorage.setItem("rd-best",String(best));}
  $("recordMessage").textContent=newRecord?"Новий рекорд! Вітаємо!":"Спробуй побити свій рекорд.";
  updateBest(); show("result");
}
$("startBtn").addEventListener("click",startGame);
$("settingsBtn").addEventListener("click",()=>{updateSettings();show("settings");});
$("level").addEventListener("input",e=>{difficulty=Number(e.target.value);updateSettings();});
$("saveSettings").addEventListener("click",()=>{localStorage.setItem("rd-level",String(difficulty));show("home");});
document.querySelectorAll("[data-screen]").forEach(b=>b.addEventListener("click",()=>show(b.dataset.screen)));
$("quitBtn").addEventListener("click",()=>{stop();show("home");});
$("againBtn").addEventListener("click",startGame);
$("resultHomeBtn").addEventListener("click",()=>show("home"));
updateSettings(); updateBest();
